﻿namespace LAB12_ANDRESFIGUEROA_1300123
{
    class CIRCULO
    {
        private double radio;
        public CIRCULO(double radi)
        {
            radio = radi;

        }
       
        public double ObtenerPerimetro()
        {
            double Perimetro = 2 * Math.PI * radio;
            return Math.Round(Perimetro, 2);
        }
        public double ObtenerArea()
        {
            double area = Math.PI * Math.Pow(radio, 2);
            return Math.Round(area, 2);
        }
        public double ObtenerVolumen()
        {
            double volumen = (4 * Math.PI * Math.Pow(radio, 3))/3;
            return Math.Round(volumen, 2);
        }
    }
    class PROGRAMA
    {
        static void Main(string[] args)
        {
            
            static void Retorno()
            {
                Console.WriteLine(" INGRESE EL VALOR DEL RADIO DEL CIRCULO: ");
                double radio = Convert.ToDouble(Console.ReadLine());


                CIRCULO CIR = new CIRCULO(radio);
                Console.WriteLine("EL PERIMETRO DEL CIRCULO ES: " + CIR.ObtenerPerimetro().ToString());
                Console.WriteLine("EL AREA DEL CIRCULO ES: " + CIR.ObtenerArea().ToString());
                Console.WriteLine("EL VOLUMEN DEL CIRCULO ES: " + CIR.ObtenerVolumen().ToString());
                Console.WriteLine();
                Console.WriteLine("¿DESEA SALIR?");
                Console.WriteLine("1. SI");
                Console.WriteLine("2. NO");
                String OPC;
                OPC = Console.ReadLine();
                switch (OPC)
                {
                    case "1":
                        Console.WriteLine("ADIOS, HASTA PRONTO.");
                        break;
                    case "2":
                        Console.Clear();
                        Retorno();
                        break;
                    default:
                        Console.WriteLine("ELIGE UNA OPCION CORRECTA");
                        break;
                }

            }

            Console.WriteLine(" INGRESE EL VALOR DEL RADIO DEL CIRCULO: ");
            double radio = Convert.ToDouble(Console.ReadLine());


            CIRCULO CIR = new CIRCULO(radio);
            Console.WriteLine("EL PERIMETRO DEL CIRCULO ES: " + CIR.ObtenerPerimetro().ToString());
            Console.WriteLine("EL AREA DEL CIRCULO ES: " + CIR.ObtenerArea().ToString());
            Console.WriteLine("EL VOLUMEN DEL CIRCULO ES: " + CIR.ObtenerVolumen().ToString());
            Console.WriteLine();
            Console.WriteLine("¿DESEA SALIR?");
            Console.WriteLine("1. SI");
            Console.WriteLine("2. NO");
            String OPC;
            OPC = Console.ReadLine();
            switch (OPC)
            {
                case "1":
                    Console.WriteLine("ADIOS, HASTA PRONTO.");
                    break;
                case "2":
                    Console.Clear();
                    Retorno();
                    break;
                default:
                    Console.WriteLine("ELIGE UNA OPCION CORRECTA, SE TE ENVIARA DE NUEVO AL MENU PRINCIPAL, PRESIONA LA TECLA ENTER.");
                    Console.ReadLine();
                    Console.Clear();
                    Retorno();
                    break;
            }
        }
    }
}