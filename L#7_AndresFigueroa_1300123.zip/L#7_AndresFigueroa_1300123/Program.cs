﻿using System.ComponentModel.Design;

namespace L_7_AndresFigueroa_1300123

{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" EJERCICIO 1 ");
            Console.WriteLine();
            Console.WriteLine(" INGRESE UN NUMERO ");
            Console.WriteLine();
            int a = 0;

            a = int.Parse(Console.ReadLine());

            if (a == 0)
            {
                Console.WriteLine(" Este numero es igual a cero ");
            }
            else
            {
                if (a > 0)
                {
                    Console.WriteLine(" Este numero es positivo ");
                }
                else
                {
                    Console.WriteLine(" Este numero es negativo ");
                }
             Console.WriteLine();
             Console.WriteLine();
             Console.WriteLine(" EJERCICIO 2 ");
             Console.WriteLine();
             Console.WriteLine(" INGRESE UN NUMERO DE DIA ");
             Console.WriteLine();
             String opcion = Console.ReadLine();
            switch (opcion)
                {
                    case "1":
                        Console.WriteLine(" Dia: Lunes ");
                        break;
                    case "2":
                        Console.WriteLine(" Dia: Martes ");
                        break;
                    case "3":
                        Console.WriteLine(" Dia: Miercoles ");
                        break;
                    case "4":
                        Console.WriteLine(" Dia: Jueves ");
                        break;  
                    case "5":
                        Console.WriteLine(" Dia: Viernes ");
                        break;
                    case "6":
                        Console.WriteLine(" Dia: Sabado ");
                        break;
                    case "7":
                        Console.WriteLine(" Dia : Domingo ");
                        break;
                    default:
                        Console.WriteLine(" El numero a ingresar debe estar conmtenido entre 1 y 7  ");
                        break;
                        
                }
                Console.WriteLine();


                









            }



        }
    }
}