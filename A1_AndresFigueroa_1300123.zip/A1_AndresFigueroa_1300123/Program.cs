﻿class program
{
    static void Main(string[] args)
    {
        string sNombre, sEdad, sCarrera, sCarnet;


        //ingreso nombre

        Console.WriteLine("Ingrese nombre:");
        sNombre = Console.ReadLine();

        //ingreso de edad

        Console.WriteLine("Ingrese edad:");
        sEdad = Console.ReadLine();

        //ingreso de carrera

        Console.WriteLine("Ingrese carrera:");
        sCarrera = Console.ReadLine();

        //ingreso carnet

        Console.WriteLine(" Ingrese carnet ");
        sCarnet = Console.ReadLine();

        Console.WriteLine("Mi segundo programa");
        Console.WriteLine(" Nombre " + sNombre);
        Console.WriteLine(" Edad " + sEdad);
        Console.WriteLine(" Carrera " + sCarrera);
        Console.WriteLine(" Carnet " + sCarnet);

        Console.Write(" Soy " + sNombre + ", tengo " + sEdad + " años y estudio la carrera de " + sCarrera);
        Console.Write(". Mi numero de carnet es " + sCarnet);
        
    }
}
