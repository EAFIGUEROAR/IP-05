﻿using System.ComponentModel.Design;

namespace L_8_AndresFigueroa_1300123
{
    internal class Program
    {
        static void Main(string[] args)
        {
          
            double Vo = 0.00;
            double Vf = 0.00;
            double t = 0.00;
            double a = 0.00;
            
           
            Console.WriteLine(" EJERCICIO 1 ");
            Console.WriteLine(" INGRESE LOS SIGUIENTES DATOS: ");
            Console.WriteLine(" INGRESE LA VELOCIDAD INICIAL");
            Vo = double.Parse(Console.ReadLine());
            Console.WriteLine(" INGRESE LA VELOCIDAD FINAL");
            Vf = double.Parse(Console.ReadLine());
            Console.WriteLine(" INGRESE LA ACELERACION ");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine(" INGRESE EL TIEMPO ");
            t = double.Parse(Console.ReadLine());
            if (Vo == 0.00 && Vf == 0.00 && a == 0.00 && t==0.00 )
            {
                Console.WriteLine(" INGRESAR VALORES CORRECTOS ");
            }
            else
            {
                if( Vf == 0.00 && Vo> 0.00 && a> 0.00 && t>0.00)
                {
                    Vf = Vo + (a * t);
                    Console.WriteLine(" LA VELOCIDAD FINAL ES: " + Vf);
                }
                else
                {
                    if (Vo==0.00 && a > 0.00 && t > 0.00 && Vf>0.00)
                    {
                        Vo = Vf - (a * t);
                        Console.WriteLine(" LA VELOCIDAD INICIAL ES: " + Vo); 
                    }
                    else
                    {
                        if (a == 0.00 && t > 0.00 && Vf > 0.00 && Vo>0.00)

                        {
                            a = (Vf - Vo) / t;
                            Console.WriteLine(" LA ACELERACION ES: " + a);
                        }
                        else
                        {
                            if (t == 0.00 && Vf > 0.00 && Vo > 0.00 && a>0.00)
                            {
                                t = (Vf - Vo) / a;
                                Console.WriteLine(" EL TIEMPO ES: " + t);
                            }
                            else
                            {
                                Console.WriteLine(" INGRESAR VALORES CORRECTOS");
                            }
                        }
                    }
                }
            }
            Console.WriteLine();
            Console.WriteLine(" EJERCICIO 2: ");
            string nombre;
            string carnet;
            double monto = 0.00;

            Console.WriteLine(" INGRESE SU NOMBRE: ");
            nombre = Console.ReadLine();
            Console.WriteLine(" INGRESE SU CARNET: ");
            carnet = Console.ReadLine();
            retorno:
            Console.WriteLine(" INGRESE UN MONTON ENTRE 0 Y 999.99: ");
            monto = double.Parse(Console.ReadLine());

            if (monto <= 999.99 && monto > 0.00)
            {

                double c = 0;
                int b100 = 0;
                int b50 = 0;
                int b20 = 0;
                int b10 = 0;
                int b5 = 0;
                int m100 = 0;
                int m25 = 0;
                int m1 = 0;

                c = monto * 100;
                b100 = (int)(c / 10000);
                c %= 10000;

                b50 = (int)(c / 5000);
                c %= 5000;

                b20 = (int)(c / 2000);
                c %= 2000;

                b10 = (int)(c / 1000);
                c %= 1000;

                b5 = (int)(c / 500);
                c %= 500;

                m100 = (int)(c / 100);
                c %= 100;

                m25 = (int)(c / 25);
                c %= 25;

                m1 = (int)(c / 1);
                c %= 1;

                Console.WriteLine(" HOLA " + nombre + "-" + carnet);
                Console.WriteLine("TIENES:");
                Console.WriteLine(b100 + " BILLETES DE Q100 ");
                Console.WriteLine(b50 + " BILLETES DE Q50 ");
                Console.WriteLine(b20 + " BILLETES DE Q20 ");
                Console.WriteLine(b10 + " BILLETES DE Q10 ");
                Console.WriteLine(b5 + " BILLETES DE Q5 ");
                Console.WriteLine(m100 + " MONEDAS DE Q1 ");
                Console.WriteLine(m25 + " MONEDAS DE Q0.25 ");
                Console.WriteLine(m1 + " MONEDAS de Q0.01 ");

            }
            else
            {
                Console.WriteLine(" INGRESAR VALORES CORRECTOS ");
                goto retorno;
            }
            


          
            



        }
    }
}