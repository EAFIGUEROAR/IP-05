﻿class project
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su nombre");
        string Nombre;

        Nombre = Console.ReadLine();

        Console.WriteLine("Hola Mundo");
        Console.WriteLine(" soy" + Nombre);

        /*
         * este es un ejemplo de comentario en varias lineas
         */

        // este es un ejemplo de comentario en una linea

        Console.Write("Hola mundo");
        Console.Write(" soy" + Nombre);
        Console.ReadKey();
    }
}
