﻿using System.Security.Cryptography.X509Certificates;

namespace L_9_ANDRESFIGUEROA_1300123
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("EJERCICIO 1");
            Console.WriteLine("BIENVENIDO");
            Console.WriteLine("PORFAVOR INDICA LA OPCION QUE REQUIERA");
            Console.WriteLine("1.POSEE CODIGO DE DESCUENTO");
            Console.WriteLine("2.NO POSEE CODIGO DE DESCUENTO");

            double a;
            String opcion = Console.ReadLine();
            switch (opcion)
            {
                case "1":
                    while (true)
                    {
                        Console.WriteLine("INGRESA EL VALOR TOTAL DE TU COMPRA");
                        if (double.TryParse(Console.ReadLine(), out a))
                            break;
                        Console.WriteLine("ESCRIBE UN VALOR NUMERICO");

                    }
                    while (a < 400)
                    {
                        double porcentaje5;
                        porcentaje5 = a - (a * 0.05);
                        Console.WriteLine("EL MONTO NO CONTIENE DESCUENTO");
                        Console.WriteLine("SU TOTAL ES: " + a);
                        break;


                    }
                    while (a >= 400)
                    {
                        if (a <= 1000)
                        {
                            double porcentaje7;
                            porcentaje7 = a - (a * 0.07) - (a * 0.05);
                            Console.WriteLine("SU TOTAL OBTUVO UN 7% DE DESCUENTO");
                            Console.WriteLine("SU TOTAL ACUTAL CON DESCUENTO ES:" + porcentaje7);

                        }
                        break;
                    }
                    while (a > 1000)
                    {
                        if (a <= 5000)
                        {
                            double porcentaje10;
                            porcentaje10 = a - (a * 0.1) - (a * 0.05);
                            Console.WriteLine("SU TOTAL OBTUVO UN 10% DE DECUENTO ");
                            Console.WriteLine("SU TOTAL ACUTAL CON DESCUENTO ES:" + porcentaje10);
                        }
                        break;
                    }
                    while (a > 5000)
                    {
                        if (a <= 15000)
                        {
                            double porcentaje15;
                            porcentaje15 = a - (a * 0.15) - (a * 0.05);
                            Console.WriteLine("SU TOTAL OBTUVO UN 15% DE DESCUENTO");
                            Console.WriteLine("SU TOTAL ACTUAL CON DESCUENTO ES: " + porcentaje15);
                        }
                        break;
                    }
                    while (a > 15000)
                    {
                        double porcentaje25;
                        porcentaje25 = a - (a * 0.25) - (a * 0.05);
                        Console.WriteLine("SU TOTAL OBTUVO UN 25% DE DESCUENTO");
                        Console.WriteLine("SU TOTAL ACTUAL CON DESCUENTO ES: " + porcentaje25);
                        break;
                    }
                    break;

                case "2":
                    while (true)
                    {
                        Console.WriteLine("INGRESA EL VALOR TOTAL DE TU COMPRA");
                        if (double.TryParse(Console.ReadLine(), out a))
                            break;
                        Console.WriteLine("ESCRIBE UN VALOR NUMERICO");

                    }
                    while (a < 400)
                    {
                        Console.WriteLine("EL MONTO NO CONTIENE DESCUENTO");
                        Console.WriteLine("SU TOTAL ES: " + a);
                        break;


                    }
                    while (a >= 400)
                    {
                        if (a <= 1000)
                        {
                            double porcentaje7;
                            porcentaje7 = a - (a * 0.07);
                            Console.WriteLine("SU TOTAL OBTUVO UN 7% DE DESCUENTO");
                            Console.WriteLine("SU TOTAL ACUTAL CON DESCUENTO ES:" + porcentaje7);

                        }
                        break;
                    }
                    while (a > 1000)
                    {
                        if (a <= 5000)
                        {
                            double porcentaje10;
                            porcentaje10 = a - (a * 0.1);
                            Console.WriteLine("SU TOTAL OBTUVO UN 10% DE DECUENTO ");
                            Console.WriteLine("SU TOTAL ACUTAL CON DESCUENTO ES:" + porcentaje10);
                        }
                        break;
                    }
                    while (a > 5000)
                    {
                        if (a <= 15000)
                        {
                            double porcentaje15;
                            porcentaje15 = a - (a * 0.15);
                            Console.WriteLine("SU TOTAL OBTUVO UN 15% DE DESCUENTO");
                            Console.WriteLine("SU TOTAL ACTUAL CON DESCUENTO ES: " + porcentaje15);
                        }
                        break;
                    }
                    while (a > 15000)
                    {
                        double porcentaje25;
                        porcentaje25 = a - (a * 0.25);
                        Console.WriteLine("SU TOTAL OBTUVO UN 25% DE DESCUENTO");
                        Console.WriteLine("SU TOTAL ACTUAL CON DESCUENTO ES: " + porcentaje25);
                        break;
                    }
                    break;



            }
            

        }



    }
}