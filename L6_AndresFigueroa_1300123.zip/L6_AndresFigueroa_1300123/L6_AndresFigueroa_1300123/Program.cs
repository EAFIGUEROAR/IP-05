﻿using System.ComponentModel.Design;
using System.Runtime.Intrinsics.X86;

namespace L6_AndresFigueroa_1300123
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" Ejercicio 1: Operaciones Aritméticas ");
            Console.WriteLine();
            double numero1 = 0.0;
            double numero2 = 0.0;
            double suma = 0.0;
            double resta = 0.0;
            double division = 0.0;
            double multiplicacion = 0.0;
            double div = 0.0;
            double mod = 0.0;


            Console.WriteLine(" Ingrese dos numeros ");
            Console.WriteLine();
            Console.WriteLine(" Ingrese el primer numero: ");
            numero1 = double.Parse(Console.ReadLine());

            Console.WriteLine(" Ingrese el segundo numero: ");
            numero2 = double.Parse(Console.ReadLine());
            Console.WriteLine();

            suma = numero1 + numero2;
            Console.WriteLine(numero1 + " + " + numero2 + " = "+ suma);

            
            resta = numero1 - numero2;
            Console.WriteLine(numero1 + " - " + numero2 + " = " + resta);

            multiplicacion = numero1 * numero2;
            Console.WriteLine(numero1 + " * " + numero2 + " = " + multiplicacion);
            
            division = numero1 / numero2;
            Console.WriteLine(numero1 + " / " + numero2 + " = " + division);
            Console.ReadLine();
            Console.WriteLine();
            Console.ReadLine();

            Console.WriteLine(" Ejercicio 2: Operaciones Booleanas ");
            Console.WriteLine();
            bool mayor = numero1 > numero2;
            bool menor = numero1 < numero2;
            bool igual = numero1 == numero2;

            Console.WriteLine(numero1 + " > " + numero2 + " = " + mayor);
            Console.WriteLine(numero1 + " < " + numero2 + " = " + menor);
            Console.WriteLine(numero1 + " = " + numero2 + " = " + igual);
            Console.WriteLine();
            Console.ReadLine();

            Console.WriteLine(" Ejercicio 3: Jerarquia de operaciones ");
            Console.WriteLine();

            double a = 0.0;
            double b = 0.0;
            double c = 0.0;

            Console.WriteLine(" Ingresar 3 numeros ");
            Console.WriteLine(" Ingresar primer numero ");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine(" Ingresar segundo numero ");
            b = double.Parse(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine(" Ingresar tercer numero ");
            c = double.Parse(Console.ReadLine());
            Console.WriteLine();

            double i = 0.0;
            double ii = 0.0;
            double iii = 0.0;
            double iv = 0.0;

            i = a * b + c;
            Console.WriteLine(" i). " + a + " * " + b + " + " + c + " = " + i);

            ii = a * (b + c);
            Console.WriteLine(" ii). " + a + " * (" + b + " + " + c + ") = " + ii);

            iii = a / (b * c);
            Console.WriteLine(" iii). " + a + " / (" + b + " * " + c + ") = " + iii);

            iv = ((3*a) + (2*b)) / (Math.Pow(c,2));
            Console.WriteLine(" iv). " + "((3*"+a+")+(2*" +b+")) / (" + c + "²) = " + iv);
            Console.ReadLine();

            Console.WriteLine(" Ecuación Cuadratica");

            double x1 = 0.0;
            double x2 = 0.0;
            if (a != 0)
            {
                if ((Math.Pow(b, 2) - (4 * a * c)) >= 0) 
                {
                    x1 = (-b + (Math.Sqrt((Math.Pow(b, 2) - 4 * a * c)))) / (2 * a);
                    x2 = (-b - (Math.Sqrt((Math.Pow(b, 2) - 4 * a * c)))) / (2 * a);
                    Console.WriteLine(" Los resultados de la ecuacion cuadratica son:");
                    Console.WriteLine();
                    Console.WriteLine(" x1= " + x1);
                    Console.WriteLine(" x2= " + x2);
                }

                else
                {
                    Console.WriteLine(" Hay un error en la ecuacion cuadratica ya que b² - 4ac es menor a cero");

                }

            }
            else
            {
                Console.WriteLine(" Hay un error en la ecuación cuadratica ya que a es igual a cero ");
            }
        }
    }
}