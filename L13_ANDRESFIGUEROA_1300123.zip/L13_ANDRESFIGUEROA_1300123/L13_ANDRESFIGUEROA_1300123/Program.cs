﻿namespace L13_ANDRESFIGUEROA_1300123
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numeros = new int[10];

            // Pide al usuario ingresar los números requeridos
            PedirNumeros(numeros);

            Console.WriteLine();

            // a). Encuentra el número más pequeño ingresado
            int numeroMinimo = EncontrarNumeroMinimo(numeros);
            Console.WriteLine("EL NUMERO MAS PEQUÑO INGRESADO ES: {0}", numeroMinimo);

            // b). Encuentra el número más grande ingresado
            int numeroMaximo = EncontrarNumeroMaximo(numeros);
            Console.WriteLine("EL NUMERO MAS GRANDE INGRESADO ES: {0}", numeroMaximo);

            // c). Calcúla la suma total de los números ingresados
            int sumaTotal = CalcularSumaTotal(numeros);
            Console.WriteLine("LA SUMA TOTAL DE LOS NUMEROS INGRESADOS ES: {0}", sumaTotal);

            // d). Orden de posición (de 0 a 9)
            Console.WriteLine("NUMEROS INGRESADOS EN ORDEN DE POSICION:");
            MostrarNumeros(numeros);

            // e). Orden inverso de posición (de 9 a 0)
            Console.WriteLine("NUMEROS INGRESADOS EN ORDEN INVERSO DE POSICION:");
            MostrarNumerosInverso(numeros);

            // f). Promedio de los números ingresados
            double promedio = CalcularPromedio(numeros);
            Console.WriteLine("EL PROMEDIO DE LOS NUMEROS INGRESADOS ES: {0}", promedio);

            // g). Suma de las posiciones pares
            int sumaPosicionesPares = CalcularSumaPosicionesPares(numeros);
            Console.WriteLine("LA SUMA DE LAS POSICIONES PARES ES: {0}", sumaPosicionesPares);

            // g). Suma de las posiciones impares
            int sumaPosicionesImpares = CalcularSumaPosicionesImpares(numeros);
            Console.WriteLine("LA SUMA DE LAS POSICIONES IMPARES ES: {0}", sumaPosicionesImpares);

            Console.ReadLine();
        }

        static void PedirNumeros(int[] numeros)
        {
            for (int i = 0; i < numeros.Length; i++)
            {
                Console.Write("INGRESE EL NUMERO {0}: ", i + 1);
                numeros[i] = Convert.ToInt32(Console.ReadLine());
            }
        }

        static int EncontrarNumeroMinimo(int[] numeros)
        {
            int numeroMinimo = numeros[0];
            for (int i = 1; i < numeros.Length; i++)
            {
                if (numeros[i] < numeroMinimo)
                {
                    numeroMinimo = numeros[i];
                }
            }
            return numeroMinimo;
        }

        static int EncontrarNumeroMaximo(int[] numeros)
        {
            int numeroMaximo = numeros[0];
            for (int i = 1; i < numeros.Length; i++)
            {
                if (numeros[i] > numeroMaximo)
                {
                    numeroMaximo = numeros[i];
                }
            }
            return numeroMaximo;
        }

        static int CalcularSumaTotal(int[] numeros)
        {
            int sumaTotal = 0;
            for (int i = 0; i < numeros.Length; i++)
            {
                sumaTotal += numeros[i];
            }
            return sumaTotal;
        }

        static void MostrarNumeros(int[] numeros)
        {
            for (int i = 0; i < numeros.Length; i++)
            {
                Console.WriteLine(numeros[i]);
            }
        }

        static void MostrarNumerosInverso(int[] numeros)
        {
            for (int i = numeros.Length - 1; i >= 0; i--)
            {
                Console.WriteLine(numeros[i]);
            }
        }

        static double CalcularPromedio(int[] numeros)
        {
            int sumaTotal = CalcularSumaTotal(numeros);
            double promedio = (double)sumaTotal / numeros.Length;
            return promedio;
        }

        static int CalcularSumaPosicionesPares(int[] numeros)
        {
            int sumaPosicionesPares = 0;
            for (int i = 0; i < numeros.Length; i += 2)
            {
                sumaPosicionesPares += numeros[i];
            }
            return sumaPosicionesPares;
        }

        static int CalcularSumaPosicionesImpares(int[] numeros)
        {
            int sumaPosicionesImpares = 0;
            for (int i = 1; i < numeros.Length; i += 2)
            {
                sumaPosicionesImpares += numeros[i];
            }
            return sumaPosicionesImpares;
        }
    }

}