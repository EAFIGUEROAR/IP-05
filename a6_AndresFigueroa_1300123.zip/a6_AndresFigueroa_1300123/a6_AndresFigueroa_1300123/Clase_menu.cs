﻿class Clase_menu
{
    static void Main(string[] args)

        {
        Console.WriteLine("Programa mi proyecto");
        Console.ReadKey();
        Console.WriteLine(" Seleccione una opción)");
        Console.WriteLine(" 1. Casa de un nivel ");
        Console.WriteLine(" 2. Casa de dos niveles ");
        string opcion = Console.ReadLine();
        switch (opcion)
        {
            case "1":
                Console.WriteLine(" Casa de un nivel ");
                break;

            case "2":
                Console.WriteLine(" Casa de dos niveles");
                break;

            default:
                Console.WriteLine(" Seleccionó una opción invalida ");
                break;


        }        


        }
        
        
        




















}
